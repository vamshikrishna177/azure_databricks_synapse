# Databricks notebook source
from pyspark.sql.functions import * 
from pyspark.sql.types import *


# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver layer script

# COMMAND ----------

# MAGIC %md
# MAGIC Data access using app

# COMMAND ----------


spark.conf.set("fs.azure.account.auth.type.storagevamshi177.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.storagevamshi177.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.storagevamshi177.dfs.core.windows.net", "d812efd9-34de-4c30-8bad-4776c9067e3a")
spark.conf.set("fs.azure.account.oauth2.client.secret.storagevamshi177.dfs.core.windows.net", "a3y8Q~Re4yQ2jHUzJjztFWO-J9VkvjtB04-i.atX")
spark.conf.set("fs.azure.account.oauth2.client.endpoint.storagevamshi177.dfs.core.windows.net", "https://login.microsoftonline.com/7d2d9779-5bfd-47ef-860c-e6fa57eb75d6/oauth2/token")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data loading 

# COMMAND ----------

# MAGIC %md 
# MAGIC ##read calender data

# COMMAND ----------

df_cal = spark.read.format('csv')\
    .option("header",True)\
        .option("inferSchema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Calendar')

# COMMAND ----------

df_cus = spark.read.format('csv')\
    .option("header",True)\
        .option("inferschema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Customers')

# COMMAND ----------

df_cat = spark.read.format('csv')\
    .option("header",True)\
        .option("inferschema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Product_Categories')

# COMMAND ----------

df_subcat = spark.read.format('csv')\
    .option("header",True)\
        .option("inferschema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Product_Subcategories')

# COMMAND ----------

df_pro = spark.read.format('csv')\
    .option("header",True)\
        .option("inferschema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Products')

# COMMAND ----------

df_ret = spark.read.format('csv')\
    .option("header",True)\
        .option("inferschema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Returns')

# COMMAND ----------

df_sales = spark.read.format('csv')\
    .option("header",True)\
        .option("inferschema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Sales*')

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

df_ter = spark.read.format('csv')\
    .option("header",True)\
        .option("inferschema", True)\
            .load('abfss://bronze@storagevamshi177.dfs.core.windows.net/AdventureWorks_Territories')

# COMMAND ----------

# MAGIC %md 
# MAGIC ###Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### #### **Calender**

# COMMAND ----------

df_cal = df_cal.withColumn('Month',month(col('Date')))\
               .withColumn('Year',year(col('Date')))
            
#df_cal:pyspark.sql.connect.dataframe.DataFrame = [Date: date]
df_cal.display()
#for c in df_cal.columns:
 #   print(repr(c))

# COMMAND ----------

df_cal.write.format('parquet')\
            .mode('append')\
            .option("path","abfss://silver@storagevamshi177.dfs.core.windows.net/AdventureWorks_Calendar")\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Customers

# COMMAND ----------

df_cus.withColumn('Fullname',(concat(col('Prefix'),lit(' '),col('FirstName'),lit(' '),col('LastName')))).display()

# COMMAND ----------

df_cus.withColumn('Fullname',concat_ws(' ',col('Prefix'),col('FirstName'),col('LastName'))).display()


# COMMAND ----------

df_cal.write.format('parquet')\
            .mode('append')\
            .option("path","abfss://silver@storagevamshi177.dfs.core.windows.net/AdventureWorks_Customers")\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Subcategories

# COMMAND ----------

df_subcat.display()

# COMMAND ----------

df_cal.write.format('parquet')\
            .mode('append')\
            .option("path", "abfss://silver@storagevamshi177.dfs.core.windows.net/AdventureWorks_Product_Subcategories")\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Products

# COMMAND ----------

df_pro = df_pro.withColumn('ProductSKU',split(col('ProductSKU'),'-')[0])\
      .withColumn('ProductName',split(col('ProductName'),'-')[0])

# COMMAND ----------

df_pro.display()

# COMMAND ----------

df_pro.write.format('parquet')\
            .mode('append')\
            .option("path", "abfss://silver@storagevamshi177.dfs.core.windows.net/AdventureWorks_Products")\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Return

# COMMAND ----------

df_ret.display()

# COMMAND ----------

df_ret.write.format('parquet')\
            .mode('append')\
            .option("path", "abfss://silver@storagevamshi177.dfs.core.windows.net/AdventureWorks_returns")\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ###Territories

# COMMAND ----------

df_ter.display()

# COMMAND ----------

df_ter.write.format('parquet')\
            .mode('append')\
            .option("path", "abfss://silver@storagevamshi177.dfs.core.windows.net/AdventureWorks_Territories")\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sales

# COMMAND ----------

df_sales.display()

# COMMAND ----------

df_sales = df_sales.withColumn('StockDate',to_timestamp('stockDate'))

# COMMAND ----------

df_sales = df_sales.withColumn('OrderNumber',regexp_replace(col('OrderNumber'),'S','T'))

# COMMAND ----------

df_sales = df_sales.withColumn('Multiply',col('OrderlineItem')*col('OrderQuantity'))

# COMMAND ----------

df_sales.display()

# COMMAND ----------

df_sales.write.format('parquet')\
            .mode('append')\
            .option("path", "abfss://silver@storagevamshi177.dfs.core.windows.net/AdventureWorks_Sales*")\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sales analysis

# COMMAND ----------

df_sales.groupBy('OrderDate').agg(count('Ordernumber').alias('total_count')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product category

# COMMAND ----------

df_cat.display()

# COMMAND ----------

df_ter.display()

# COMMAND ----------

